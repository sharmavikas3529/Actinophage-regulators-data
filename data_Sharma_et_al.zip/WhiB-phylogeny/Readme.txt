#Align sequences using online mafft server (https://mafft.cbrc.jp/alignment/server/)
whib.fa > whib.aln

#manual curation and realign using mafft (https://mafft.cbrc.jp/alignment/server/)
whib.aln.man > whib.aln.man.realign 

#trim using trimal
trimal -in whib.aln.man.realign -out whib.aln.man.realign.trim -gappyout

#predict evolutionary model using prottest-3.4.2
whib.aln.man.realign.trim


#ml tree using Fasttree
fasttree -lg whib.aln.man.realign.trim > whib.aln.man.realign.trim.tree






