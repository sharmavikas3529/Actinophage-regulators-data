library(ggplot2)
library(plyr)
library(ggwordcloud)
library(pheatmap)
library(gggenes)
library(data.table)

#load file
gg <- read.csv("whib-annotation.csv", sep = "\t", header = T)
#replace "CDD:" from column 2nd
#gg$V2 <- gsub('CDD:', '', gg$V2)

    
    
#import file with species information
sp <- read.csv("PhagesDB_whib-tab-14-05-2020.csv", sep = "\t", header = T)

#remove everything after match "." from column V1 in file gg
gsub("\\..*","",gg$Acc)->gg$Accession
#loop mapping from species file to gg
for(l in 1:dim(gg)[1]){
    
    sp[which(sp[,"Accession"]==as.character(gg[l,"Accession"]))[1],"Phage.Name"]->gg[l,"Phage.Name"]}
    #
    for(l in 1:dim(gg)[1]){
    
    sp[which(sp[,"Accession"]==as.character(gg[l,"Accession"]))[1],"Host"]->gg[l,"Host"]}

    #
     for(l in 1:dim(gg)[1]){
    
    sp[which(sp[,"Accession"]==as.character(gg[l,"Accession"]))[1],"Cluster"]->gg[l,"Cluster"]}
    #
         for(l in 1:dim(gg)[1]){
    
    sp[which(sp[,"Accession"]==as.character(gg[l,"Accession"]))[1],"Temperate"]->gg[l,"Temperate."]}
    #
             for(l in 1:dim(gg)[1]){
    
    sp[which(sp[,"Accession"]==as.character(gg[l,"Accession"]))[1],"WhiB_Domain"]->gg[l,"WhiB_Domain"]}

    
#add positive and negative strand for gene direction
gg$direction <- ifelse(gg$strand == "+", 1, -1)

#add genus information
sub("_\\S*", "", gg$Host)->gg$genus

#replace #NA FROM COLUMN DOMAIN IF EMPLTY FROM PRODUCT
library(data.table)
setDT(gg)
gg[ domain == "#N/A", domain := product ]

#replace hypothetical protein by HP
gsub('hypothetical_protein', 'HP', gg$domain)->gg$domain


#FILTER FALSE POSITIVE WHICH DO NOT CONTAIN WHIB DOMAIN
whib <- read.csv("ref_domain-id.csv", sep = "\t", header = T)
#only those match from the table
gg[gg$Acc %in% whib$Current, ]->gg1
droplevels(gg1)->gg1
gg1$Gene <- ifelse(gg1$domain == "WhiB", "WhiB", "Others")

#plot final run with 6 genomes per Host species
levels(gg1$Cluster)->NS
for(i in 1:length(NS)){
    subset(gg1, Cluster == NS[i])-> strain
    droplevels(strain)->strain
    
    strain[!duplicated(strain$Accession), ]->un
    droplevels(un)->un
    
    setDT(un)[, if(.N>1) head(.SD,6) else .SD , by = Host]->un1
    droplevels(un1)->un1
    
    strain[strain$Accession %in% un1$Accession, ]->strain1
    droplevels(strain1)->strain1
#plot and save   
    t<-ggplot(strain1, aes(xmin = start, xmax = stop, y = Acc, fill = Host, label = domain, forward = direction)) + geom_gene_arrow(arrowhead_height = unit(6, "mm"), show.legend = TRUE, arrowhead_width = unit(3, "mm")) + facet_wrap(~Host, scales = "free_y", ncol = 1,) + scale_fill_brewer(palette = "Set3") + theme_genes() + ggtitle(NS[i]) +  geom_gene_label(align = "left") + ylab("")
    ggsave(paste(NS[i], "without-dummies.pdf"),plot=t, path="/home/IBT/sharma/Phage-synteny/article-regulators/8th-overview/data_and_scripts/synteny/whib/plot/", device = "pdf", dpi = 300, width = 14, height = 10)
    
}
