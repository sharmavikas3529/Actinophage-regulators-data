library(ggplot2)
library(plyr)
library(ggwordcloud)
library(pheatmap)
library(gggenes)
library(data.table)

#load file genomic loci annotataion 5 kb up and downstream
gg <- read.csv("annoatation.csv", sep = "\t", header = T)
    
#import file for mapping information
sp <- read.csv("PhagesDB_tab-14-05-2020.csv", sep = "\t", header = T)

#remove everything after match "." from column V1 in file gg
gsub("\\..*","",gg$Acc)->gg$Accession
#loop mapping from species file to gg
for(l in 1:dim(gg)[1]){
    
    sp[which(sp[,"Accession"]==as.character(gg[l,"Accession"]))[1],"Phage.Name"]->gg[l,"Phage.Name"]}
    #
    for(l in 1:dim(gg)[1]){
    
    sp[which(sp[,"Accession"]==as.character(gg[l,"Accession"]))[1],"Host"]->gg[l,"Host"]}

    #
     for(l in 1:dim(gg)[1]){
    
    sp[which(sp[,"Accession"]==as.character(gg[l,"Accession"]))[1],"Cluster"]->gg[l,"Cluster"]}
    #
         for(l in 1:dim(gg)[1]){
    
    sp[which(sp[,"Accession"]==as.character(gg[l,"Accession"]))[1],"Temperate"]->gg[l,"Temperate."]}
    #
       for(l in 1:dim(gg)[1]){
    
    sp[which(sp[,"Accession"]==as.character(gg[l,"Accession"]))[1],"Lsr2_Domain"]->gg[l,"Lsr2_Domain"]}
  
    
#add positive and negative strand for gene direction
gg$direction <- ifelse(gg$strand == "+", 1, -1)

#add genus information
sub("_\\S*", "", gg$Host)->gg$genus



#replace #NA FROM COLUMN DOMAIN IF EMPLTY FROM PRODUCT
library(data.table)
setDT(gg)
gg[ domain == "#N/A", domain := product ]

#replace hypothetical protein name by HP
gsub('hypothetical_protein', 'HP', gg$domain)->gg$domain

##write mapped file
write.csv(gg,"mapped.csv", row.names = FALSE)


##########################start analysis using gggenes # part 2
setwd("/home/IBT/sharma/Phage-synteny/lsr2-project/phagedb/phage-db-2020/positives/5kb-plot-prokka/missing-5b-plot/plot")
library(ggplot2)
library(plyr)
library(ggwordcloud)
library(pheatmap)
library(gggenes)
library(ggrepel)
library(data.table)

#load file
gg <- read.csv("gmapped.csv", sep = "\t", header = T)

subset(gg, Lsr2_Domain > 0)-> gg1
droplevels(gg1)->gg1


#add gene
ifelse(gg1$domain == "Lsr2", "Lsr2", "Others")->gg1$Gene


#plots syteny 4 loci per genus
levels(gg1$Cluster)->NS
for(i in 1:length(NS)){
    subset(gg1, Cluster == NS[i])-> strain
    droplevels(strain)->strain
    
    strain[!duplicated(strain$Accession), ]->un
    droplevels(un)->un
    
    setDT(un)[, if(.N>1) head(.SD,4) else .SD , by = Host]->un1
    droplevels(un1)->un1
    
    strain[strain$Accession %in% un1$Accession, ]->strain1
    droplevels(strain1)->strain1
    
    t<-ggplot(strain1, aes(xmin = start, xmax = stop, y = Acc, fill = Host, label = domain,forward = direction)) + geom_gene_arrow(arrowhead_height = unit(6, "mm"), show.legend = TRUE, arrowhead_width = unit(3, "mm")) + facet_wrap(~Host, scales = "free_y", ncol = 1,) + scale_fill_brewer(palette = "Set3") + theme_genes() + ggtitle(NS[i]) +  geom_gene_label(align = "left") + ylab("")
    
    ggsave(paste(NS[i], "without-dummies.pdf"),plot=t, path="/home/IBT/sharma/Phage-synteny/article-regulators/8th-overview/data_and_scripts/synteny/lsr2/plot/", device = "pdf", dpi = 300, width = 14, height = 10)
}
###################################################################################################################################
