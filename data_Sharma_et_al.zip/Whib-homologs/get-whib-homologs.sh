#! /bin/bash

#loop over all genomes files from Table S1(*.fna) in a folder 
for filename in *.fna;

#formatdb database
do makeblastdb -in $filename -title $filename -dbtype nucl -out $filename

mkdir "$filename"_results;

cd "$filename"_results

#index file

samtools faidx ../$filename

cp ../"$filename".fai ./

#'comparing genome to WHIB sequence library'
blastall -p tblastn -d ../$filename -i ../whib.fasta -o RTprobes_tBn -a 4 -m 8 -e 1e-5
#awk '{n=$9+120; $15=n} {p=$10-120; $16=p} {y=$9-120; $17=y} {z=$10+120; $18=z} ($9>$10&&$16>0) {print $2 "\ttBn\tRT\t" $16 "\t" $15 "\t.\t-\t.\tID="$2"_"$9"_"$10} ($10>$9&&$17>0) {print $2 "\ttBn\tRT\t" $17 "\t" $18 "\t.\t+\t.\tID="$2"_"$9"_"$10}' RTprobes_tBn > RTprobes_tBn.gff3
#convert to bed
awk '($9<$10) { print $2  "\t" $9 "\t" $10 "\t" $2"_"$1"_"$9"_"$10 "\t" $12 "\t+" } ($9>$10) { print $2 "\t" $10 "\t" $9 "\t" $2"_"$1"_"$10"_"$9 "\t" $12 "\t-" }' RTprobes_tBn > RTprobes_tBn.bed


sort -k1,1 -k2,2n RTprobes_tBn.bed > RTprobes_tBn.bed.sorted

bedtools merge -i RTprobes_tBn.bed.sorted -s > RTprobes_tBn.bed.sorted.merge.bed

awk '{print $1 "\t" $2 "\t" $3 "\t" $1"_"$2"_"$3 "\t1\t" $4 }' RTprobes_tBn.bed.sorted.merge.bed > RTprobes_tBn.bed.sorted.merge.bed.clust

#add 5kb up & down
awk '{$2-=5000;$3+=5000}1' OFS='\t' RTprobes_tBn.bed.sorted.merge.bed.clust > RTprobes_tBn.bed.sorted.merge.bed.clust-5kb

#replace - values in second column to 1
awk 'BEGIN {OFS="\t"}; $2<0 {$2=1} 1' RTprobes_tBn.bed.sorted.merge.bed.clust-5kb > RTprobes_tBn.bed.sorted.merge.bed.clust-5kb_format

#add 500bp up & down
awk '{$2-=500;$3+=500}1' OFS='\t' RTprobes_tBn.bed.sorted.merge.bed.clust > RTprobes_tBn.bed.sorted.merge.bed.clust-5bp
#replace - values in second column to 1
awk 'BEGIN {OFS="\t"}; $2<0 {$2=1} 1' RTprobes_tBn.bed.sorted.merge.bed.clust-5bp > RTprobes_tBn.bed.sorted.merge.bed.clust-5bp_format


#adjust 5 kb if missing
line=$(cut -f 2 "$filename".fai)

echo "$line"

x=$(echo $line)
echo | awk -vX="$x" 'BEGIN { OFS = "\t"; }; { if ($3 > X) $3 = X; else $3 = $3; }; 1' RTprobes_tBn.bed.sorted.merge.bed.clust-5kb_format > RTprobes_tBn.bed.sorted.merge.bed.clust-5kb_format_adjusted




#samtools faidx ../$filename

#extract genomic loci

bedtools getfasta -fi ../$filename -bed RTprobes_tBn.bed.sorted.merge.bed.clust-5kb_format_adjusted -fo "$filename"_5KB-flanking.fasta
bedtools getfasta -fi ../$filename -bed RTprobes_tBn.bed.sorted.merge.bed.clust-5kb_format -fo "$filename"_5KB-flanking.fasta
bedtools getfasta -fi ../$filename -bed RTprobes_tBn.bed.sorted.merge.bed.clust-5bp_format -fo "$filename"_5BP-flanking.fasta

#translate sequences into proteins
translate -l 30 "$filename"_5BP-flanking.fasta -o clust_RTprobes_tBn_200aa.fa
sed 's/  .*//g' clust_RTprobes_tBn_200aa.fa | sed 's/ //g' | sed 's/--/_/g' | sed 's/\./_/g' | sed 's/__/_/g' | sed 's/:/_/g' > clust_RTprobes_tBn_200aa.fa.format



#blast
blastall -p blastp -i clust_RTprobes_tBn_200aa.fa.format -d ../whib.fasta -o "$filename"_whib_probes_tBn_200aa_vs_RePprobes -a 4 -m 8 -e 1e-5
#blast proteins >90 length choose because shortest sequence in query library.
awk '!x[$1]++' "$filename"_whib_probes_tBn_200aa_vs_RePprobes | grep -v 'GEN' | awk '($8-$7>60) {print $0}'| cut -f 1  | sort -u > "$filename"_whib_blast200_RePGEM_list_nr

extractFromFasta.pl clust_RTprobes_tBn_200aa.fa.format list "$filename"_whib_blast200_RePGEM_list_nr > "$filename"_whib_proteins.fa



cd ..
rm *.nin *.nhr *.nsq *.fai

done;
 done
