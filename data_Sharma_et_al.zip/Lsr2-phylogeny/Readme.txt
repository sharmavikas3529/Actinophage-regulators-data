#align sequences using mafft online (https://mafft.cbrc.jp/alignment/server/)
all-lsr2.fasta > all-lsr2.aln

#manual curation and realign using mafft (https://mafft.cbrc.jp/alignment/server/)
all-lsr2.aln > all-lsr2-m.aln.realign.man.realign.man


#remove gaps using trimal  
trimal -in all-lsr2-m.aln.realign.man.realign.man -out all-lsr2-m.aln.realign.man.realign.man.trim -gappyout

#find best model using prottest-3.4.2
all-lsr2-m.aln.realign.man.realign.man.trim

#ml tree using fasttree
fasttree -lg all-lsr2-m.aln.realign.man.realign.man.trim > all-lsr2-m.aln.realign.man.realign.man.trim.tree

