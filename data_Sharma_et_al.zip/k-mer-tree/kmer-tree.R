library(seqinr)
library(Biostrings)
library(ape)
library(textmineR)
library(ggtree)
library(ggplot2)
library(tibble)
#refernce (https://bioinformaticshome.com/bioinformatics_tutorials/R/phylogeny_estimation.html, http://yulab-smu.top/treedata-book/chapter13.html)
#PATH 
setwd("/home/IBT/sharma/Phage-synteny/lsr2-project/complete-genome-rpsblastn/phageDB-2020/rplot/sequences")
#In the folder containing only the viral sequences
nfiles <- length(dir())
seqdat <- vector("list", nfiles)

for(i in 1:nfiles){
seqdat[[i]] <- read.fasta(file=dir()[i])
}

label <- sapply(1:nfiles, function(k) unlist(strsplit(dir()[k], "[.]"))[1])
names(seqdat) <- label

seqdat_join <- lapply(seqdat, function(k) paste(toupper(unlist(k)),collapse="") )


#
#enumerate all 5-mers
dna <- c("A","C","G","T")
kmer5 <- expand.grid(dna, dna, dna, dna, dna)
kmer5 <- apply(kmer5, 1, function(k) paste(k, collapse=""))

#function for counting all possible kmers (k=5) given a single dna string
kmercount <- function(data){
  sapply(1:length(kmer5), function(k)
  length(unlist(gregexpr2(kmer5[k], data)))
  )}

#vector of counts for all possible kmers (k=5) for all viral sequences
kmer_features <- lapply(seqdat_join, function(k) kmercount(k))


#Collect k-mer counts into a data frame
M <- do.call(rbind, kmer_features)


#The correct input for CalcJSDivergence is the (unnormalised) count vector
JSdist <- CalcJSDivergence(M)

#plot.phylo(bionj(JSdist), type="unrooted", cex=0.8, rotate.tree=95)

#save tree file
as.phylo(bionj(JSdist))->pr
#add tree info 
#add sequence info mapping table
tp <- read.delim("../treeinfo.csv", sep = "\t")
sub("_\\S*", "", tp$Host)->tp$genus

#######################
#gheatmap
#color tips
#make list to color tips
#make list to color tips
#rename tree file
pr-> tree
myList <- as.list(tp$Acc)
names(myList) <- tp$Cluster
tree <- groupOTU(tree, myList)
#filtered information from tp 
pt <- read.delim("TFdomains.csv", sep = ",", row.names=1)
pt %>% select(WhiB, Lsr2)->pt1
as.matrix(pt1)->pt2
pt2[pt2 == 0] <- NA
ggtree(tree, branch.length='none', aes(color=group)) + geom_tiplab(size=0.5) + theme(legend.position="none")
#circular plot
ggtree(tree, branch.length='none', layout='circular', aes(color=group)) + geom_tiplab(size=0.1) + geom_tiplab2(aes(label=group, angle=angle, hjust=1, offset=1), check_overlap = TRUE, size=1) + theme(legend.position="none") -> p
gheatmap(p, pt1, offset=2, width=0.2, font.size=3, colnames_angle=90) + theme(legend.position="none")
ggsave("../ML-TREE-Regulators-mapping-whib-lsr2.pdf", width = 12, height = 10)


#rectangular plot
ggtree(pr, branch.length='none') %<+% tp + geom_tippoint(aes(color=Cluster, label=Cluster), size=0.5) +  geom_tiplab2(aes(label=Cluster,  color=Cluster), size=0.5, offset=2, angle=360) + geom_tiplab(aes(color=Cluster), size = 0.5)  + theme(legend.position="none") + geom_tiplab2(aes(label=Temperate, color=Temperate), size=0.5, offset=3, angle=360) +  geom_tiplab2(aes(label=genus, color=genus), size=0.5, offset=4, angle=360) + ggplot2::xlim(-10, 200)->oo
gheatmap(oo, pt2, offset=7, width=0.2, font.size=2, colnames_angle=90) + theme(legend.position="none")
ggsave("ML-TREE-Regulators-mapping-retangular.pdf", width = 12, height = 48)

